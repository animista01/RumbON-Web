<?php

// A user has many nimkus and has many and belongs to followers
class User extends Eloquent 
{
}