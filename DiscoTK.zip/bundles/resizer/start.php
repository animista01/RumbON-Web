<?php

Autoloader::map(array(
	'Resizer'	=> __DIR__ . DS . 'resizer.php'
));