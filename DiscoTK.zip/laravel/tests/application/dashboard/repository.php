<?php namespace Dashboard;

/**
 * This class is used for testing the auto-loading of classes
 * that are mapped by namesapce.
 */
class Repository {}